حزمة تطبيق سول — SOL PERFUME
================================
إصدار التطبيق: 1.9   (com.sol.accounts)

01-Android
  SOL-Accounts-1.9.apk  ← للتسطيب المباشر على أي موبايل أندرويد
  SOL-Accounts-1.9.aab  ← ده اللي بيترفع على Google Play Console
  لينك تحميل مباشر: https://github.com/rafatsaeed719-ui/sol-app/raw/downloads/SOL-Accounts.apk

02-Windows
  SOL-Setup-1.9.exe  ← ملف التسطيب للكمبيوتر: افتحه ← تسطيب ← أيقونة "سول" على سطح المكتب
  SOL-Update-1.9.exe ← تحديث صامت: دبل كليك يسطّب 1.9 ويشيل النسخ القديمة ويفتح البرنامج
  (لو ظهرت الشاشة الزرقا: More info ← Run anyway) — لينك مباشر:
  https://github.com/rafatsaeed719-ui/sol-app/raw/downloads/SOL-Setup.exe

03-Google-Play
  أيقونة 512×512، صورة Feature graphic 1024×500، 8 صور شاشة 1080×1920،
  وملف store-listing.txt فيه الاسم والوصف وإجابات أمان البيانات.

04-App-Screens        لقطات شاشة حقيقية من البرنامج (العميل والإدارة)
05-Promo-Video        الفيديو الدعائي 39 ثانية بالطول (1080×1920) بالصوت
06-Presentation       العرض التقديمي PowerPoint + نسخة PDF
07-Privacy-Policy     سياسة الخصوصية عربي + إنجليزي (HTML و PDF)
                      اللينك العام لجوجل بلاي: https://github.com/rafatsaeed719-ui/sol-app/blob/downloads/PRIVACY.md
08-Stickers-Labels    ستيكرات 5×3 سم، ستيكر QR الفيسبوك، ليبلات الزجاجة
09-Source-Code        الكود الكامل (www = البرنامج نفسه، android = تطبيق الموبايل،
                      windows / windows-lite = نسخ الكمبيوتر، firestore.rules = قواعد الأمان)

10-Firebase-Rules     قواعد الأمان (فيها منصة المحلات) — تتلصق في Firebase ← Firestore ← Rules ← Publish

منصة المحلات (جديد في 1.8):
  • صاحب المحل: التطبيق ← تبويب "صاحب محل" ← "سجّل محلك" ← يستنى موافقتك
  • إنت: المزيد ← "المحلات والاشتراكات" (موافقة / تجديد / إيقاف / فتح المحل)
           المزيد ← "إعدادات المنصة" (سعر الاشتراك الشهري، أيام التجربة، رقم الدفع)
  • زباين أي محل: يختاروا المحل من قايمة شاشة الدخول ويشوفوا حسابهم معاه بس

جديد في 1.9:
  • مصروفاتي: إضافة/تعديل/حذف أي مصروف بالبند والتاريخ وطريقة الدفع، وتوزيعها على البنود
  • الخزنة: وارد (تحصيلات + إيداع) وصادر (مصروفات + رد مرتجعات + سحب) والمتبقي، برصيد افتتاحي وحركة كاملة و Excel
  • المرتجع: كلي أو جزئي من أي فاتورة، برد فلوس كاش أو خصم من حساب العميل، ويظهر للعميل في فاتورته وكشف حسابه
  • التقارير: المرتجعات والمصروفات وصافي المبيعات (Excel فيه شيتات المرتجعات والمصروفات)
  ⚠️ لازم تلصق قواعد 10-Firebase-Rules الجديدة في Firebase عشان المصروفات والخزنة والمرتجعات يشتغلوا

مهم جداً — احتفظ بيهم ومتشاركهمش:
    كلمة سره ومفتاحه مكتوبين في 09-Source-Code/android/app/build.gradle
    لو ضاع، مش هتقدر تنزل تحديث فوق التطبيق المتسطب.
  • مشروع Firebase: sol-accounts  (console.firebase.google.com)
  • حساب الإدارة: rafatsaeed719@gmail.com

رفع التطبيق على Google Play (باختصار):
  1. play.google.com/console ← Create app ← الاسم والوصف من store-listing.txt
  2. ارفع الأيقونة والـ Feature graphic وصور الشاشة من 03-Google-Play
  3. حط لينك سياسة الخصوصية وجاوب Data safety من store-listing.txt
  4. Testing أو Production ← Create release ← ارفع SOL-Accounts-1.9.aab
